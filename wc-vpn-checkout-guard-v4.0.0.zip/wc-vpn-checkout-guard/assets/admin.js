(function () {
  'use strict';
  function ready(fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }
  ready(function () {
    var preview = document.getElementById('wcvg-preview');
    if (!preview) return;
    var map = {
      popup_bg: '--wcvg-bg', overlay_bg: '--wcvg-overlay', title_color: '--wcvg-title', text_color: '--wcvg-text',
      accent_color: '--wcvg-accent', button_text_color: '--wcvg-button-text', border_radius: '--wcvg-radius'
    };
    Object.keys(map).forEach(function (id) {
      var field = document.getElementById('wcvg-' + id);
      if (!field) return;
      field.addEventListener('input', function () {
        var value = field.value;
        if (id === 'border_radius') value += 'px';
        preview.style.setProperty(map[id], value);
      });
    });
    var title = document.querySelector('input[name$="[title]"]');
    var message = document.querySelector('textarea[name$="[message_vpn]"]');
    var button = document.querySelector('input[name$="[button_label]"]');
    var close = document.querySelector('input[name$="[close_label]"]');
    function bind(field, selector) { if (!field) return; field.addEventListener('input', function () { var target = preview.querySelector(selector); if (target) target.textContent = field.value; }); }
    bind(title, 'h3'); bind(message, 'p'); bind(button, 'span'); bind(close, 'small');
    var iconSelect = document.getElementById('wcvg-popup-icon');
    var iconMarkup = {
      'shield-alert': '<path d="M12 3 4.5 6v5.5c0 4.5 3.2 7.7 7.5 9.5 4.3-1.8 7.5-5 7.5-9.5V6L12 3Z"/><path d="M12 8v4m0 3h.01"/>',
      'shield-check': '<path d="M12 3 4.5 6v5.5c0 4.5 3.2 7.7 7.5 9.5 4.3-1.8 7.5-5 7.5-9.5V6L12 3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>',
      'alert-triangle': '<path d="m10.3 4.2-8 14A1.8 1.8 0 0 0 3.9 21h16.2a1.8 1.8 0 0 0 1.6-2.8l-8-14a1.9 1.9 0 0 0-3.4 0Z"/><path d="M12 9v4m0 3h.01"/>',
      'lock': '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 1 1 8 0v3m-4 5v2"/>',
      'globe': '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
      'wifi-off': '<path d="m3 3 18 18M8.5 8.5A14 14 0 0 1 21 12m-15.5.5A14 14 0 0 1 3 12m4 4a8 8 0 0 1 10 0M10 20h.01"/>',
      'ban': '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
      'info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/>'
    };
    if (iconSelect) iconSelect.addEventListener('change', function () {
      var holder = preview.querySelector('[data-preview-icon]');
      if (holder) holder.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (iconMarkup[iconSelect.value] || iconMarkup['shield-alert']) + '</svg>';
    });
  });
})();
