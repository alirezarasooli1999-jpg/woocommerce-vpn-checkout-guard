(function () {
  'use strict';
  function init() {
    var modal = document.querySelector('[data-wcvg-modal="1"]');
    if (!modal) return;
    document.documentElement.classList.add('wcvg-modal-open');
    document.body.style.overflow = 'hidden';
    var primary = modal.querySelector('.wcvg-primary-button');
    if (primary) primary.focus({ preventScroll: true });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        // بستن با Escape عمداً غیرفعال است تا پیام محدودیت نادیده گرفته نشود.
        event.preventDefault();
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
