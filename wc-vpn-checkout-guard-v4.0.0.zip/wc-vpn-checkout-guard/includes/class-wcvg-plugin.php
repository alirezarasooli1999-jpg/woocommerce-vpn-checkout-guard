<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * هسته افزونه محافظ پرداخت.
 * تمرکز این نسخه بر اعتبارسنجی پیش از پرداخت، عدم دخالت در بازگشت درگاه و fail-open پیش‌فرض است.
 */
final class WCVG_Plugin {
	const OPTION = 'wcvg_v4_settings';
	const LOG_OPTION = 'wcvg_v4_logs';
	private static $instance = null;
	private $settings = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->migrate_legacy_settings();
		$this->settings = wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_checkout_popup' ), 99 );
		add_action( 'template_redirect', array( $this, 'checkout_preflight' ), 2 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_classic_checkout' ), 20, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_meta', array( $this, 'validate_block_checkout' ), 20, 1 );
		add_shortcode( 'wcvg_notice', array( $this, 'notice_shortcode' ) );
		add_action( 'admin_post_wcvg_test_geo', array( $this, 'test_geolocation' ) );
		add_action( 'admin_post_wcvg_test_vpn', array( $this, 'test_vpn' ) );
	}

	private function migrate_legacy_settings() {
		if ( false !== get_option( self::OPTION, false ) ) { return; }
		$legacy = get_option( 'wcvg_settings', array() );
		if ( ! is_array( $legacy ) || empty( $legacy ) ) { return; }
		$defaults = self::defaults();
		$migrated = $defaults;
		if ( isset( $legacy['enabled'] ) ) { $migrated['enabled'] = absint( $legacy['enabled'] ) ? 1 : 0; }
		if ( isset( $legacy['api_key'] ) ) { $migrated['vpn_api_key'] = sanitize_text_field( $legacy['api_key'] ); }
		foreach ( array( 'block_vpn', 'block_proxy', 'block_tor', 'block_datacenter', 'logging' ) as $key ) {
			if ( isset( $legacy[ $key ] ) ) { $migrated[ $key ] = absint( $legacy[ $key ] ) ? 1 : 0; }
		}
		if ( ! empty( $legacy['block_foreign'] ) ) {
			$country = isset( $legacy['country_code'] ) ? strtoupper( substr( sanitize_text_field( $legacy['country_code'] ), 0, 2 ) ) : 'IR';
			$migrated['policy'] = 'custom';
			$migrated['allowed_countries'] = $country;
		}
		if ( isset( $legacy['notice_page_id'] ) ) { $migrated['notice_page_id'] = absint( $legacy['notice_page_id'] ); }
		if ( isset( $legacy['notice_title'] ) ) { $migrated['title'] = sanitize_text_field( $legacy['notice_title'] ); }
		if ( isset( $legacy['notice_message'] ) ) { $migrated['message_vpn'] = sanitize_textarea_field( $legacy['notice_message'] ); }
		foreach ( array( 'gateway_ids', 'allowlist_ips', 'trusted_proxy_ips' ) as $key ) {
			if ( isset( $legacy[ $key ] ) ) { $migrated[ $key ] = sanitize_textarea_field( $legacy[ $key ] ); }
		}
		update_option( self::OPTION, $migrated, false );
	}

	public static function defaults() {
		return array(
			'enabled' => 1,
			'policy' => 'iran', // iran | custom | vpn | both
			'allowed_countries' => 'IR',
			'unknown_country' => 'allow',
			'block_vpn' => 0,
			'block_proxy' => 0,
			'block_tor' => 0,
			'block_datacenter' => 0,
			'vpn_api_key' => '',
			'vpn_failure' => 'allow',
			'display_mode' => 'popup', // popup | page | both
			'notice_page_id' => 0,
			'title' => 'امکان ادامه پرداخت وجود ندارد',
			'message_country' => 'در حال حاضر امکان ثبت سفارش از کشور محل اتصال شما وجود ندارد. لطفاً از داخل ایران و با اتصال اینترنت مجاز دوباره تلاش کنید.',
			'message_vpn' => 'به نظر می‌رسد اتصال اینترنت شما از طریق VPN یا پراکسی برقرار شده است. لطفاً آن را خاموش کنید و سپس دوباره تلاش کنید.',
			'message_unknown' => 'در حال حاضر امکان تشخیص کشور اتصال شما وجود ندارد. لطفاً کمی بعد دوباره تلاش کنید یا با پشتیبانی فروشگاه تماس بگیرید.',
			'message_vpn_error' => 'در حال حاضر سرویس بررسی اتصال در دسترس نیست. لطفاً چند دقیقه دیگر دوباره تلاش کنید.',
			'popup_icon' => 'shield-alert',
			'popup_bg' => '#ffffff',
			'overlay_bg' => '#172033',
			'overlay_opacity' => 72,
			'title_color' => '#202a44',
			'text_color' => '#596579',
			'accent_color' => '#6554d9',
			'button_text_color' => '#ffffff',
			'button_label' => 'بررسی مجدد و بازگشت به پرداخت',
			'close_label' => 'بازگشت به سبد خرید',
			'border_radius' => 18,
			'popup_width' => 480,
			'gateway_ids' => '',
			'allowlist_ips' => '',
			'trusted_proxy_ips' => '',
			'logging' => 1,
			'dry_run' => 0,
			'cache_minutes' => 720,
			'vpn_daily_limit' => 900,
		);
	}

	private function refresh_settings() {
		$this->settings = wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	public function admin_menu() {
		add_submenu_page( 'woocommerce', 'محافظ پرداخت ووکامرس', 'محافظ پرداخت', 'manage_woocommerce', 'wcvg-settings', array( $this, 'settings_page' ) );
	}

	public function register_settings() {
		register_setting( 'wcvg_settings_group', self::OPTION, array( $this, 'sanitize_settings' ) );
	}

	private function clean_color( $value, $fallback ) {
		$color = sanitize_hex_color( $value );
		return $color ? $color : $fallback;
	}

	public function sanitize_settings( $input ) {
		$d = self::defaults();
		$input = is_array( $input ) ? $input : array();
		$out = $d;
		$checks = array( 'enabled', 'block_vpn', 'block_proxy', 'block_tor', 'block_datacenter', 'logging', 'dry_run' );
		foreach ( $checks as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? 1 : 0;
		}
		$out['policy'] = isset( $input['policy'] ) && in_array( $input['policy'], array( 'iran', 'custom', 'vpn', 'both' ), true ) ? $input['policy'] : 'iran';
		$out['allowed_countries'] = isset( $input['allowed_countries'] ) ? strtoupper( preg_replace( '/[^a-zA-Z,\s]/', '', sanitize_text_field( $input['allowed_countries'] ) ) ) : 'IR';
		if ( '' === trim( $out['allowed_countries'] ) ) { $out['allowed_countries'] = 'IR'; }
		$out['unknown_country'] = isset( $input['unknown_country'] ) && 'block' === $input['unknown_country'] ? 'block' : 'allow';
		$out['vpn_api_key'] = isset( $input['vpn_api_key'] ) ? sanitize_text_field( $input['vpn_api_key'] ) : '';
		$out['vpn_failure'] = isset( $input['vpn_failure'] ) && 'block' === $input['vpn_failure'] ? 'block' : 'allow';
		$out['display_mode'] = isset( $input['display_mode'] ) && in_array( $input['display_mode'], array( 'popup', 'page', 'both' ), true ) ? $input['display_mode'] : 'popup';
		$out['notice_page_id'] = isset( $input['notice_page_id'] ) ? absint( $input['notice_page_id'] ) : 0;
		foreach ( array( 'title', 'button_label', 'close_label' ) as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : $d[ $key ];
		}
		foreach ( array( 'message_country', 'message_vpn', 'message_unknown', 'message_vpn_error', 'gateway_ids', 'allowlist_ips', 'trusted_proxy_ips' ) as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? sanitize_textarea_field( $input[ $key ] ) : $d[ $key ];
		}
		$icons = array( 'shield-alert', 'shield-check', 'alert-triangle', 'lock', 'globe', 'wifi-off', 'ban', 'info' );
		$out['popup_icon'] = isset( $input['popup_icon'] ) && in_array( $input['popup_icon'], $icons, true ) ? $input['popup_icon'] : $d['popup_icon'];
		foreach ( array( 'popup_bg', 'overlay_bg', 'title_color', 'text_color', 'accent_color', 'button_text_color' ) as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? $this->clean_color( $input[ $key ], $d[ $key ] ) : $d[ $key ];
		}
		$out['overlay_opacity'] = isset( $input['overlay_opacity'] ) ? min( 95, max( 20, absint( $input['overlay_opacity'] ) ) ) : 72;
		$out['border_radius'] = isset( $input['border_radius'] ) ? min( 40, max( 0, (int) $input['border_radius'] ) ) : 18;
		$out['popup_width'] = isset( $input['popup_width'] ) ? min( 720, max( 300, absint( $input['popup_width'] ) ) ) : 480;
		$out['cache_minutes'] = isset( $input['cache_minutes'] ) ? min( 1440, max( 5, absint( $input['cache_minutes'] ) ) ) : 720;
		$out['vpn_daily_limit'] = isset( $input['vpn_daily_limit'] ) ? min( 100000, absint( $input['vpn_daily_limit'] ) ) : 900;
		return $out;
	}

	public function admin_assets( $hook ) {
		if ( 'woocommerce_page_wcvg-settings' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wcvg-admin', WCVG_URL . 'assets/admin.css', array(), WCVG_VERSION );
		wp_enqueue_script( 'wcvg-admin', WCVG_URL . 'assets/admin.js', array(), WCVG_VERSION, true );
	}

	public function frontend_assets() {
		if ( ! function_exists( 'is_checkout' ) || ( ! is_checkout() && empty( $_GET['wcvg_notice'] ) ) || ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' ) ) ) {
			return;
		}
		wp_enqueue_style( 'wcvg-frontend', WCVG_URL . 'assets/frontend.css', array(), WCVG_VERSION );
		wp_enqueue_script( 'wcvg-frontend', WCVG_URL . 'assets/frontend.js', array(), WCVG_VERSION, true );
	}

	private function parse_list( $value ) {
		$items = preg_split( '/[\r\n,;]+/', (string) $value );
		return array_values( array_filter( array_map( 'trim', $items ) ) );
	}

	private function client_ip() {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? trim( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		if ( ! filter_var( $remote, FILTER_VALIDATE_IP ) ) {
			return '';
		}
		$trusted = $this->parse_list( $this->settings['trusted_proxy_ips'] );
		if ( in_array( $remote, $trusted, true ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$chain = array_reverse( explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
			foreach ( $chain as $candidate ) {
				$candidate = trim( $candidate );
				if ( filter_var( $candidate, FILTER_VALIDATE_IP ) && ! in_array( $candidate, $trusted, true ) ) {
					return $candidate;
				}
			}
		}
		return $remote;
	}

	private function get_country_code( $ip ) {
		$cache_key = 'wcvg4_country_' . md5( $ip );
		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
		$country = '';
		// فقط از مسیر محلی ووکامرس استفاده می‌کنیم؛ api_fallback=false مانع تماس بیرونی در زمان پرداخت است.
		if ( class_exists( 'WC_Geolocation' ) ) {
			$geo = WC_Geolocation::geolocate_ip( $ip, false, false );
			if ( is_array( $geo ) && ! empty( $geo['country'] ) ) {
				$country = strtoupper( sanitize_text_field( $geo['country'] ) );
			}
		}
		set_transient( $cache_key, $country, absint( $this->settings['cache_minutes'] ) * MINUTE_IN_SECONDS );
		return $country;
	}

	private function vpn_lookup( $ip ) {
		if ( empty( $this->settings['vpn_api_key'] ) ) {
			return new WP_Error( 'wcvg_no_vpn_key', 'کلید سرویس تشخیص VPN تنظیم نشده است.' );
		}
		$key = 'wcvg4_vpn_' . md5( $ip );
		$cached = get_transient( $key );
		if ( false !== $cached ) {
			if ( is_array( $cached ) && isset( $cached['error'] ) ) { return new WP_Error( 'wcvg_vpn_cached_error', $cached['error'] ); }
			return $cached;
		}
		$limit = absint( $this->settings['vpn_daily_limit'] );
		$count_key = 'wcvg4_vpn_count_' . gmdate( 'Ymd' );
		$count = absint( get_transient( $count_key ) );
		if ( $limit > 0 && $count >= $limit ) {
			set_transient( $key, array( 'error' => 'سقف درخواست روزانه سرویس VPN تکمیل شده است.' ), 2 * MINUTE_IN_SECONDS );
			return new WP_Error( 'wcvg_vpn_daily_limit', 'سقف درخواست روزانه سرویس VPN تکمیل شده است.' );
		}
		set_transient( $count_key, $count + 1, DAY_IN_SECONDS );
		$response = wp_remote_post( 'https://api.ipapi.is/', array(
			'timeout' => 4,
			'redirection' => 0,
			'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
			'body' => wp_json_encode( array( 'q' => $ip, 'key' => $this->settings['vpn_api_key'] ) ),
			'user-agent' => 'WCVG/' . WCVG_VERSION,
		) );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			$error = 'سرویس تشخیص VPN پاسخ معتبر نداد.';
			set_transient( $key, array( 'error' => $error ), 2 * MINUTE_IN_SECONDS );
			return new WP_Error( 'wcvg_vpn_api_error', $error );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['ip'] ) ) {
			$error = 'پاسخ سرویس تشخیص VPN معتبر نیست.';
			set_transient( $key, array( 'error' => $error ), 2 * MINUTE_IN_SECONDS );
			return new WP_Error( 'wcvg_vpn_bad_response', $error );
		}
		$result = array(
			'is_vpn' => ! empty( $body['is_vpn'] ),
			'is_proxy' => ! empty( $body['is_proxy'] ),
			'is_tor' => ! empty( $body['is_tor'] ),
			'is_datacenter' => ! empty( $body['is_datacenter'] ),
		);
		set_transient( $key, $result, absint( $this->settings['cache_minutes'] ) * MINUTE_IN_SECONDS );
		return $result;
	}

	private function evaluate() {
		$ip = $this->client_ip();
		if ( ! $ip || ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return array( 'blocked' => false, 'reason' => 'unknown_ip', 'unknown' => true );
		}
		if ( in_array( $ip, $this->parse_list( $this->settings['allowlist_ips'] ), true ) ) {
			return array( 'blocked' => false, 'reason' => 'allowlisted' );
		}
		$policy = $this->settings['policy'];
		$reasons = array();
		$unknown = false;
		if ( in_array( $policy, array( 'iran', 'custom', 'both' ), true ) ) {
			$country = $this->get_country_code( $ip );
			if ( ! $country ) {
				$unknown = true;
				if ( 'block' === $this->settings['unknown_country'] ) {
					$reasons[] = 'unknown_country';
				}
			} else {
				$allowed = 'iran' === $policy || 'both' === $policy ? array( 'IR' ) : array_map( 'strtoupper', $this->parse_list( $this->settings['allowed_countries'] ) );
				if ( ! in_array( $country, $allowed, true ) ) {
					$reasons[] = 'country';
				}
			}
		}
		if ( in_array( $policy, array( 'vpn', 'both' ), true ) && ( $this->settings['block_vpn'] || $this->settings['block_proxy'] || $this->settings['block_tor'] || $this->settings['block_datacenter'] ) ) {
			$vpn = $this->vpn_lookup( $ip );
			if ( is_wp_error( $vpn ) ) {
				if ( 'block' === $this->settings['vpn_failure'] ) {
					$reasons[] = 'vpn_service_error';
				}
			} else {
				if ( $this->settings['block_vpn'] && $vpn['is_vpn'] ) { $reasons[] = 'vpn'; }
				if ( $this->settings['block_proxy'] && $vpn['is_proxy'] ) { $reasons[] = 'proxy'; }
				if ( $this->settings['block_tor'] && $vpn['is_tor'] ) { $reasons[] = 'tor'; }
				if ( $this->settings['block_datacenter'] && $vpn['is_datacenter'] ) { $reasons[] = 'datacenter'; }
			}
		}
		$blocked = ! empty( $reasons );
		if ( $blocked && $this->settings['dry_run'] ) {
			$this->log_event( $ip, 'آزمایشی: ' . implode( ',', $reasons ) );
			$blocked = false;
		} else {
			$this->log_event( $ip, $blocked ? implode( ',', $reasons ) : 'مجاز' );
		}
		return array( 'blocked' => $blocked, 'reason' => $reasons, 'unknown' => $unknown, 'ip' => $ip );
	}

	private function selected_gateway_is_target( $gateway = '' ) {
		$ids = array_map( 'sanitize_key', $this->parse_list( $this->settings['gateway_ids'] ) );
		return empty( $ids ) || ( $gateway && in_array( $gateway, $ids, true ) );
	}

	private function request_is_checkout_flow() {
		// درخواست‌های REST/AJAX و مسیرهای متداول callback درگاه نباید وارد پیش‌بررسی صفحه Checkout شوند.
		if ( isset( $_GET['wc-api'] ) || isset( $_GET['wc_api'] ) || isset( $_GET['wc-api-request'] ) ) {
			return false;
		}
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return false;
		}
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return false;
		}
		if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
			return false;
		}
		return true;
	}

	public function checkout_preflight() {
		if ( empty( $this->settings['enabled'] ) || ! $this->request_is_checkout_flow() ) {
			return;
		}
		if ( isset( $_GET['wcvg_notice'] ) || isset( $_GET['wcvg_recheck'] ) ) {
			// صفحه هشدار یک بار بارگذاری می‌شود؛ لینک بررسی مجدد بدون مجوز دور زدن، دوباره IP را ارزیابی می‌کند.
			if ( isset( $_GET['wcvg_notice'] ) && ! isset( $_GET['wcvg_recheck'] ) ) {
				return;
			}
		}
		if ( ! $this->selected_gateway_is_target( $this->session_gateway() ) ) {
			return;
		}
		$result = $this->evaluate();
		if ( empty( $result['blocked'] ) ) {
			return;
		}
		$this->send_to_notice( $result['reason'] );
	}

	private function session_gateway() {
		if ( function_exists( 'WC' ) && WC()->session ) {
			return sanitize_key( (string) WC()->session->get( 'chosen_payment_method', '' ) );
		}
		return '';
	}

	private function send_to_notice( $reasons ) {
		$reason = is_array( $reasons ) ? ( in_array( 'country', $reasons, true ) ? 'country' : ( in_array( 'unknown_country', $reasons, true ) ? 'unknown' : ( in_array( 'vpn_service_error', $reasons, true ) ? 'vpn_error' : 'vpn' ) ) ) : 'vpn';
		$mode = $this->settings['display_mode'];
		if ( in_array( $mode, array( 'page', 'both' ), true ) && $this->settings['notice_page_id'] && 'publish' === get_post_status( absint( $this->settings['notice_page_id'] ) ) ) {
			$url = add_query_arg( array( 'wcvg_notice' => '1', 'wcvg_reason' => $reason ), get_permalink( absint( $this->settings['notice_page_id'] ) ) );
		} else {
			$url = add_query_arg( array( 'wcvg_notice' => '1', 'wcvg_reason' => $reason ), wc_get_checkout_url() );
		}
		wp_safe_redirect( $url );
		exit;
	}

	private function customer_message( $reason ) {
		if ( 'country' === $reason ) { return $this->settings['message_country']; }
		if ( 'unknown' === $reason ) { return $this->settings['message_unknown']; }
		if ( 'vpn_error' === $reason ) { return $this->settings['message_vpn_error']; }
		return $this->settings['message_vpn'];
	}

	private function icon_svg( $icon ) {
		$paths = array(
			'shield-alert' => '<path d="M12 3 4.5 6v5.5c0 4.5 3.2 7.7 7.5 9.5 4.3-1.8 7.5-5 7.5-9.5V6L12 3Z"/><path d="M12 8v4m0 3h.01"/>',
			'shield-check' => '<path d="M12 3 4.5 6v5.5c0 4.5 3.2 7.7 7.5 9.5 4.3-1.8 7.5-5 7.5-9.5V6L12 3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>',
			'alert-triangle' => '<path d="m10.3 4.2-8 14A1.8 1.8 0 0 0 3.9 21h16.2a1.8 1.8 0 0 0 1.6-2.8l-8-14a1.9 1.9 0 0 0-3.4 0Z"/><path d="M12 9v4m0 3h.01"/>',
			'lock' => '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 1 1 8 0v3m-4 5v2"/>',
			'globe' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
			'wifi-off' => '<path d="m3 3 18 18M8.5 8.5A14 14 0 0 1 21 12m-15.5.5A14 14 0 0 1 3 12m4 4a8 8 0 0 1 10 0M10 20h.01"/>',
			'ban' => '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
			'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/>',
		);
		$path = isset( $paths[ $icon ] ) ? $paths[ $icon ] : $paths['shield-alert'];
		return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $path . '</svg>';
	}

	private function notice_markup( $reason, $as_modal = false ) {
		$reason = sanitize_key( $reason );
		$title = esc_html( $this->settings['title'] );
		$message = esc_html( $this->customer_message( $reason ) );
		$checkout = wc_get_checkout_url();
		$retry = add_query_arg( 'wcvg_recheck', '1', remove_query_arg( array( 'wcvg_notice', 'wcvg_reason' ), $checkout ) );
		$style = sprintf(
			'--wcvg-bg:%1$s;--wcvg-overlay:%2$s;--wcvg-overlay-opacity:%3$s;--wcvg-title:%4$s;--wcvg-text:%5$s;--wcvg-accent:%6$s;--wcvg-button-text:%7$s;--wcvg-radius:%8$dpx;--wcvg-width:%9$dpx;',
			esc_attr( $this->settings['popup_bg'] ), esc_attr( $this->settings['overlay_bg'] ), esc_attr( $this->settings['overlay_opacity'] / 100 ), esc_attr( $this->settings['title_color'] ), esc_attr( $this->settings['text_color'] ), esc_attr( $this->settings['accent_color'] ), esc_attr( $this->settings['button_text_color'] ), absint( $this->settings['border_radius'] ), absint( $this->settings['popup_width'] )
		);
		$icon = $this->icon_svg( $this->settings['popup_icon'] );
		$close = '<a class="wcvg-secondary-link" href="' . esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' ) ) . '">' . esc_html( $this->settings['close_label'] ) . '</a>';
		$body = '<div class="wcvg-dialog" role="alertdialog" aria-modal="true" aria-labelledby="wcvg-dialog-title" aria-describedby="wcvg-dialog-message" style="' . $style . '"><div class="wcvg-dialog-icon">' . $icon . '</div><h2 id="wcvg-dialog-title">' . $title . '</h2><p id="wcvg-dialog-message">' . nl2br( $message ) . '</p><a class="wcvg-primary-button" href="' . esc_url( $retry ) . '">' . esc_html( $this->settings['button_label'] ) . '</a>' . $close . '</div>';
		if ( $as_modal ) {
			return '<div class="wcvg-modal" data-wcvg-modal="1" style="' . $style . '" dir="rtl"><div class="wcvg-backdrop"></div>' . $body . '</div>';
		}
		return '<div class="wcvg-page-notice" dir="rtl" style="' . $style . '">' . $body . '</div>';
	}

	public function render_checkout_popup() {
		if ( empty( $this->settings['enabled'] ) || empty( $_GET['wcvg_notice'] ) || ! $this->request_is_checkout_flow() ) { return; }
		$has_notice_page = $this->settings['notice_page_id'] && 'publish' === get_post_status( absint( $this->settings['notice_page_id'] ) );
		if ( 'page' === $this->settings['display_mode'] && $has_notice_page ) { return; }
		$reason = isset( $_GET['wcvg_reason'] ) ? sanitize_key( wp_unslash( $_GET['wcvg_reason'] ) ) : 'vpn';
		echo $this->notice_markup( $reason, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function notice_shortcode() {
		if ( empty( $_GET['wcvg_notice'] ) ) { return ''; }
		$reason = isset( $_GET['wcvg_reason'] ) ? sanitize_key( wp_unslash( $_GET['wcvg_reason'] ) ) : 'vpn';
		$page_notice = $this->notice_markup( $reason, false );
		if ( 'both' === $this->settings['display_mode'] ) {
			return $this->notice_markup( $reason, true ) . $page_notice;
		}
		return $page_notice;
	}

	public function validate_classic_checkout( $data, $errors ) {
		if ( empty( $this->settings['enabled'] ) || ! is_object( $errors ) || ! method_exists( $errors, 'add' ) ) { return; }
		$gateway = isset( $data['payment_method'] ) ? sanitize_key( $data['payment_method'] ) : '';
		if ( ! $this->selected_gateway_is_target( $gateway ) ) { return; }
		$result = $this->evaluate();
		if ( ! empty( $result['blocked'] ) ) {
			$reason = in_array( 'country', $result['reason'], true ) ? 'country' : ( in_array( 'unknown_country', $result['reason'], true ) ? 'unknown' : ( in_array( 'vpn_service_error', $result['reason'], true ) ? 'vpn_error' : 'vpn' ) );
			$errors->add( 'wcvg_payment_restricted', $this->customer_message( $reason ) );
		}
	}

	public function validate_block_checkout( $order ) {
		if ( empty( $this->settings['enabled'] ) || ! is_object( $order ) || ! method_exists( $order, 'get_payment_method' ) ) { return; }
		if ( ! $this->selected_gateway_is_target( $order->get_payment_method() ) ) { return; }
		$result = $this->evaluate();
		if ( ! empty( $result['blocked'] ) ) {
			$reason = in_array( 'country', $result['reason'], true ) ? 'country' : ( in_array( 'unknown_country', $result['reason'], true ) ? 'unknown' : ( in_array( 'vpn_service_error', $result['reason'], true ) ? 'vpn_error' : 'vpn' ) );
			$message = $this->customer_message( $reason );
			// Store API این استثنا را به پیام اعتبارسنجی Checkout Block تبدیل می‌کند؛ قبل از اجرای درگاه.
			if ( class_exists( '\Automattic\\WooCommerce\\StoreApi\\Exceptions\\RouteException' ) ) {
				throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'wcvg_payment_restricted', $message, 400 );
			}
			throw new Exception( $message );
		}
	}

	private function log_event( $ip, $result ) {
		if ( empty( $this->settings['logging'] ) ) { return; }
		$logs = get_option( self::LOG_OPTION, array() );
		if ( ! is_array( $logs ) ) { $logs = array(); }
		$logs[] = array(
			'time' => current_time( 'mysql' ),
			'ip_hash' => substr( hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ), 0, 12 ),
			'result' => sanitize_text_field( $result ),
		);
		if ( count( $logs ) > 100 ) { $logs = array_slice( $logs, -100 ); }
		update_option( self::LOG_OPTION, $logs, false );
	}

	public function test_geolocation() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'اجازه دسترسی ندارید.' ); }
		check_admin_referer( 'wcvg_test_geo' );
		$ip = $this->client_ip();
		$country = $ip ? $this->get_country_code( $ip ) : '';
		$url = add_query_arg( 'wcvg_geo_test', $country ? rawurlencode( $country ) : 'unknown', admin_url( 'admin.php?page=wcvg-settings' ) );
		wp_safe_redirect( $url );
		exit;
	}

	public function test_vpn() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'اجازه دسترسی ندارید.' ); }
		check_admin_referer( 'wcvg_test_vpn' );
		$this->refresh_settings();
		$ip = $this->client_ip();
		$result = $ip ? $this->vpn_lookup( $ip ) : new WP_Error( 'no_ip' );
		$state = is_wp_error( $result ) ? 'failed' : 'success';
		wp_safe_redirect( add_query_arg( 'wcvg_vpn_test', $state, admin_url( 'admin.php?page=wcvg-settings' ) ) );
		exit;
	}

	public function settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		$this->refresh_settings();
		$opt = self::OPTION;
		$pages = get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'ASC' ) );
		$logs = get_option( self::LOG_OPTION, array() );
		?>
		<div class="wrap wcvg-admin" dir="rtl">
			<div class="wcvg-admin-header"><div class="wcvg-admin-logo">🛡️</div><div><h1>محافظ پرداخت ووکامرس</h1><p>کنترل دسترسی جغرافیایی و محافظت از مرحله پرداخت <span>نسخه <?php echo esc_html( WCVG_VERSION ); ?></span></p></div></div>
			<?php if ( isset( $_GET['wcvg_geo_test'] ) ) : ?><div class="notice notice-info"><p><?php echo 'unknown' === $_GET['wcvg_geo_test'] ? 'کشور IP شناسایی نشد. دیتابیس محلی MaxMind ووکامرس را بررسی کنید.' : 'کد کشور شناسایی‌شده: ' . esc_html( sanitize_text_field( wp_unslash( $_GET['wcvg_geo_test'] ) ) ); ?></p></div><?php endif; ?>
			<?php if ( isset( $_GET['wcvg_vpn_test'] ) ) : ?><div class="notice notice-info"><p><?php echo 'success' === sanitize_key( wp_unslash( $_GET['wcvg_vpn_test'] ) ) ? 'اتصال سرویس تشخیص VPN موفق بود.' : 'اتصال ناموفق بود؛ کلید API و دسترسی خروجی سرور را بررسی کنید.'; ?></p></div><?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'wcvg_settings_group' ); ?>
				<div class="wcvg-admin-layout"><main>
					<section class="wcvg-card"><h2>تنظیمات اصلی</h2>
						<label class="wcvg-toggle"><input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[enabled]" value="1" <?php checked( $this->settings['enabled'], 1 ); ?>><span class="wcvg-toggle-ui"></span><span><strong>فعال‌سازی محافظ پرداخت</strong><small>با غیرفعال کردن این گزینه، هیچ محدودیتی روی فرایند خرید اعمال نمی‌شود.</small></span></label>
						<label class="wcvg-toggle"><input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[dry_run]" value="1" <?php checked( $this->settings['dry_run'], 1 ); ?>><span class="wcvg-toggle-ui"></span><span><strong>حالت آزمایشی (بدون مسدودسازی)</strong><small>قوانین را بررسی و رویدادها را ثبت می‌کند، اما مانع پرداخت مشتری نمی‌شود.</small></span></label>
						<div class="wcvg-field"><label for="wcvg-policy">سیاست محدودیت دسترسی</label><select id="wcvg-policy" name="<?php echo esc_attr( $opt ); ?>[policy]"><option value="iran" <?php selected( $this->settings['policy'], 'iran' ); ?>>فقط ایران مجاز باشد</option><option value="custom" <?php selected( $this->settings['policy'], 'custom' ); ?>>کشورهای انتخابی مجاز باشند</option><option value="vpn" <?php selected( $this->settings['policy'], 'vpn' ); ?>>فقط بررسی VPN و Proxy</option><option value="both" <?php selected( $this->settings['policy'], 'both' ); ?>>محدودیت کشور + بررسی VPN</option></select><small>مشخص می‌کند افزونه کشور اتصال، VPN یا هر دو را برای اجازه پرداخت بررسی کند.</small></div>
						<div class="wcvg-field"><label for="wcvg-countries">کد کشورهای مجاز</label><input id="wcvg-countries" type="text" name="<?php echo esc_attr( $opt ); ?>[allowed_countries]" value="<?php echo esc_attr( $this->settings['allowed_countries'] ); ?>" placeholder="IR,AE,TR"><small>فقط در حالت «کشورهای انتخابی» استفاده می‌شود. کد دوحرفی کشورها را با ویرگول جدا کنید؛ مانند IR,AE,TR.</small></div>
						<div class="wcvg-field"><label for="wcvg-unknown-country">اگر کشور IP شناسایی نشد</label><select id="wcvg-unknown-country" name="<?php echo esc_attr( $opt ); ?>[unknown_country]"><option value="allow" <?php selected( $this->settings['unknown_country'], 'allow' ); ?>>اجازه ادامه پرداخت (پیشنهادی)</option><option value="block" <?php selected( $this->settings['unknown_country'], 'block' ); ?>>جلوگیری از پرداخت</option></select><small>اگر دیتابیس کشور در دسترس نباشد، رفتار افزونه را مشخص می‌کند. حالت اجازه، احتمال اختلال در فروش را کمتر می‌کند.</small></div>
					</section>
					<section class="wcvg-card"><h2>تشخیص VPN و پراکسی</h2><p class="wcvg-intro">این بخش مستقل از محدودیت کشور است و برای تشخیص VPN به سرویس بیرونی نیاز دارد. استفاده از آن اختیاری است.</p>
						<div class="wcvg-field"><label for="wcvg-api-key">کلید سرویس تشخیص VPN</label><input id="wcvg-api-key" type="password" autocomplete="new-password" name="<?php echo esc_attr( $opt ); ?>[vpn_api_key]" value="<?php echo esc_attr( $this->settings['vpn_api_key'] ); ?>"><small>بدون کلید، محدودیت کشور همچنان کار می‌کند؛ اما تشخیص VPN و Proxy غیرفعال می‌ماند. کلید فقط در سرور ذخیره می‌شود.</small></div>
						<?php foreach ( array( 'block_vpn' => 'مسدودسازی VPN', 'block_proxy' => 'مسدودسازی پراکسی', 'block_tor' => 'مسدودسازی شبکه Tor', 'block_datacenter' => 'مسدودسازی IP دیتاسنتر' ) as $key => $label ) : ?><label class="wcvg-check"><input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $this->settings[ $key ], 1 ); ?>><span><strong><?php echo esc_html( $label ); ?></strong><small><?php echo 'block_datacenter' === $key ? 'ممکن است بعضی کاربران عادی یا اینترنت سازمانی را اشتباه شناسایی کند.' : 'در صورت فعال بودن، اتصال‌های شناسایی‌شده از این نوع اجازه ادامه پرداخت نخواهند داشت.'; ?></small></span></label><?php endforeach; ?>
						<div class="wcvg-field"><label>سقف درخواست روزانه سرویس VPN</label><input type="number" min="0" max="100000" name="<?php echo esc_attr( $opt ); ?>[vpn_daily_limit]" value="<?php echo esc_attr( $this->settings['vpn_daily_limit'] ); ?>"><small>برای کنترل مصرف API؛ مقدار پیش‌فرض ۹۰۰ درخواست در روز است. صفر یعنی بدون سقف محلی.</small></div>
						<div class="wcvg-field"><label for="wcvg-vpn-failure">در صورت خطای سرویس VPN</label><select id="wcvg-vpn-failure" name="<?php echo esc_attr( $opt ); ?>[vpn_failure]"><option value="allow" <?php selected( $this->settings['vpn_failure'], 'allow' ); ?>>اجازه ادامه پرداخت</option><option value="block" <?php selected( $this->settings['vpn_failure'], 'block' ); ?>>جلوگیری از پرداخت</option></select><small>اگر سرویس تشخیص پاسخ ندهد، مشخص می‌کند پرداخت مجاز باشد یا متوقف شود.</small></div>
					</section>
					<section class="wcvg-card"><h2>نمایش پیام هشدار</h2>
						<div class="wcvg-field"><label for="wcvg-display">نوع نمایش هشدار</label><select id="wcvg-display" name="<?php echo esc_attr( $opt ); ?>[display_mode]"><option value="popup" <?php selected( $this->settings['display_mode'], 'popup' ); ?>>پاپ‌آپ</option><option value="page" <?php selected( $this->settings['display_mode'], 'page' ); ?>>صفحه اختصاصی</option><option value="both" <?php selected( $this->settings['display_mode'], 'both' ); ?>>هر دو (پاپ‌آپ روی صفحه اختصاصی)</option></select><small>نحوه نمایش پیام به مشتریانی را مشخص می‌کند که طبق قوانین افزونه مجاز به پرداخت نیستند.</small></div>
						<div class="wcvg-field"><label for="wcvg-notice-page">برگه اختصاصی هشدار</label><select id="wcvg-notice-page" name="<?php echo esc_attr( $opt ); ?>[notice_page_id]"><option value="0">انتخاب نشده</option><?php foreach ( $pages as $page ) : ?><option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $this->settings['notice_page_id'], $page->ID ); ?>><?php echo esc_html( $page->post_title ); ?></option><?php endforeach; ?></select><small>برای نمایش صفحه اختصاصی، یک برگه بسازید و کد کوتاه [wcvg_notice] را داخل آن قرار دهید.</small></div>
						<div class="wcvg-field"><label>عنوان هشدار</label><input type="text" name="<?php echo esc_attr( $opt ); ?>[title]" value="<?php echo esc_attr( $this->settings['title'] ); ?>"><small>عنوان اصلی پنجره هشدار برای مشتری نمایش داده می‌شود.</small></div>
						<div class="wcvg-field"><label>پیام محدودیت کشور</label><textarea rows="3" name="<?php echo esc_attr( $opt ); ?>[message_country]"><?php echo esc_textarea( $this->settings['message_country'] ); ?></textarea><small>این متن زمانی نمایش داده می‌شود که کشور اتصال در فهرست کشورهای مجاز نباشد.</small></div>
						<div class="wcvg-field"><label>پیام تشخیص VPN یا Proxy</label><textarea rows="3" name="<?php echo esc_attr( $opt ); ?>[message_vpn]"><?php echo esc_textarea( $this->settings['message_vpn'] ); ?></textarea><small>این متن به مشتریانی نمایش داده می‌شود که اتصال VPN یا پراکسی آن‌ها شناسایی شده باشد.</small></div>
						<div class="wcvg-field"><label>پیام شناسایی نشدن کشور</label><textarea rows="2" name="<?php echo esc_attr( $opt ); ?>[message_unknown]"><?php echo esc_textarea( $this->settings['message_unknown'] ); ?></textarea><small>برای زمانی است که دیتابیس محلی نتواند کشور IP را تشخیص دهد و سیاست شما مسدودسازی باشد.</small></div>
						<div class="wcvg-field"><label>پیام خطای سرویس تشخیص VPN</label><textarea rows="2" name="<?php echo esc_attr( $opt ); ?>[message_vpn_error]"><?php echo esc_textarea( $this->settings['message_vpn_error'] ); ?></textarea><small>در صورت اختلال سرویس تشخیص VPN و انتخاب سیاست مسدودسازی خطا، این پیام نمایش داده می‌شود.</small></div>
					</section>
					<section class="wcvg-card"><h2>طراحی و شخصی‌سازی پاپ‌آپ</h2><p class="wcvg-intro">رنگ‌ها را تغییر دهید و پیش‌نمایش زنده را در کنار تنظیمات مشاهده کنید.</p>
						<div class="wcvg-design-grid">
							<div>
								<?php $colors = array( 'popup_bg' => array( 'پس‌زمینه پنجره', 'رنگ سطح اصلی پاپ‌آپ را تغییر می‌دهد.' ), 'overlay_bg' => array( 'پس‌زمینه پشت پنجره', 'رنگ لایه‌ای را تعیین می‌کند که صفحه سایت را پشت هشدار می‌پوشاند.' ), 'title_color' => array( 'رنگ عنوان', 'رنگ تیتر اصلی هشدار را تنظیم می‌کند.' ), 'text_color' => array( 'رنگ متن', 'رنگ توضیحات و لینک ثانویه پاپ‌آپ را تغییر می‌دهد.' ), 'accent_color' => array( 'رنگ اصلی و دکمه', 'رنگ آیکن و دکمه اصلی هشدار را مشخص می‌کند.' ), 'button_text_color' => array( 'رنگ نوشته دکمه', 'رنگ نوشته روی دکمه اصلی را تنظیم می‌کند.' ) ); foreach ( $colors as $key => $item ) : ?><div class="wcvg-color-field"><div><label for="wcvg-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $item[0] ); ?></label><small><?php echo esc_html( $item[1] ); ?></small></div><input id="wcvg-<?php echo esc_attr( $key ); ?>" type="color" name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $this->settings[ $key ] ); ?>"></div><?php endforeach; ?>
								<div class="wcvg-field"><label>آیکن هشدار</label><select id="wcvg-popup-icon" name="<?php echo esc_attr( $opt ); ?>[popup_icon]"><?php foreach ( array( 'shield-alert' => 'سپر هشدار', 'shield-check' => 'سپر تأیید', 'alert-triangle' => 'مثلث هشدار', 'lock' => 'قفل', 'globe' => 'کره زمین', 'wifi-off' => 'قطع اتصال', 'ban' => 'ممنوع', 'info' => 'اطلاعات' ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $this->settings['popup_icon'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select><small>نماد متناسب با نوع پیام هشدار را انتخاب کنید.</small></div>
								<div class="wcvg-field"><label>متن دکمه اصلی</label><input type="text" name="<?php echo esc_attr( $opt ); ?>[button_label]" value="<?php echo esc_attr( $this->settings['button_label'] ); ?>"><small>متن دکمه بررسی مجدد و بازگشت به پرداخت.</small></div>
								<div class="wcvg-field"><label>متن لینک ثانویه</label><input type="text" name="<?php echo esc_attr( $opt ); ?>[close_label]" value="<?php echo esc_attr( $this->settings['close_label'] ); ?>"><small>متن لینک بازگشت به سبد خرید.</small></div>
								<div class="wcvg-field"><label>گردی گوشه‌ها (پیکسل)</label><input id="wcvg-border_radius" type="number" min="0" max="40" name="<?php echo esc_attr( $opt ); ?>[border_radius]" value="<?php echo esc_attr( $this->settings['border_radius'] ); ?>"><small>میزان گرد بودن گوشه‌های پنجره هشدار را تعیین می‌کند.</small></div>
								<div class="wcvg-field"><label>عرض پنجره (پیکسل)</label><input type="number" min="300" max="720" name="<?php echo esc_attr( $opt ); ?>[popup_width]" value="<?php echo esc_attr( $this->settings['popup_width'] ); ?>"><small>عرض پنجره در نمایشگرهای بزرگ؛ در موبایل به‌صورت خودکار تنظیم می‌شود.</small></div>
								<div class="wcvg-field"><label>تیرگی پس‌زمینه (%)</label><input type="number" min="20" max="95" name="<?php echo esc_attr( $opt ); ?>[overlay_opacity]" value="<?php echo esc_attr( $this->settings['overlay_opacity'] ); ?>"><small>میزان تیره شدن صفحه پشت پاپ‌آپ را تعیین می‌کند.</small></div>
							</div>
							<div class="wcvg-preview-wrap"><strong>پیش‌نمایش زنده</strong><div class="wcvg-preview" id="wcvg-preview"><div class="wcvg-preview-icon" data-preview-icon="1"><?php echo $this->icon_svg( $this->settings['popup_icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><h3><?php echo esc_html( $this->settings['title'] ); ?></h3><p><?php echo esc_html( $this->settings['message_vpn'] ); ?></p><span><?php echo esc_html( $this->settings['button_label'] ); ?></span><small><?php echo esc_html( $this->settings['close_label'] ); ?></small></div><small>این پیش‌نمایش نمونه‌ای از ظاهر پاپ‌آپ است؛ متن نهایی بر اساس دلیل محدودیت انتخاب می‌شود.</small></div>
						</div>
					</section>
					<section class="wcvg-card"><h2>تنظیمات پیشرفته و سازگاری</h2>
						<div class="wcvg-field"><label>شناسه درگاه‌های مشمول</label><textarea rows="2" name="<?php echo esc_attr( $opt ); ?>[gateway_ids]" placeholder="zarinpal,bankmellat"><?php echo esc_textarea( $this->settings['gateway_ids'] ); ?></textarea><small>اختیاری است. شناسه‌ها را با ویرگول جدا کنید. خالی بودن این فیلد یعنی همه درگاه‌ها مشمول قوانین هستند.</small></div>
						<div class="wcvg-field"><label>IPهای مجاز (فهرست استثنا)</label><textarea rows="2" name="<?php echo esc_attr( $opt ); ?>[allowlist_ips]"><?php echo esc_textarea( $this->settings['allowlist_ips'] ); ?></textarea><small>IPهای ثابت و مورد اعتماد را وارد کنید تا از محدودیت‌های این افزونه مستثنا باشند؛ هر IP در یک خط.</small></div>
						<div class="wcvg-field"><label>IP پراکسی‌ها و CDNهای مورد اعتماد</label><textarea rows="2" name="<?php echo esc_attr( $opt ); ?>[trusted_proxy_ips]"><?php echo esc_textarea( $this->settings['trusted_proxy_ips'] ); ?></textarea><small>فقط IP سرورهای پراکسی خود را وارد کنید. هدر IP ارسالی از پراکسی ناشناس قابل اعتماد نیست.</small></div>
						<div class="wcvg-field"><label>مدت نگهداری نتیجه تشخیص (دقیقه)</label><input type="number" min="5" max="1440" name="<?php echo esc_attr( $opt ); ?>[cache_minutes]" value="<?php echo esc_attr( $this->settings['cache_minutes'] ); ?>"><small>برای کاهش پردازش و درخواست‌های تکراری، نتیجه تشخیص برای این مدت ذخیره می‌شود.</small></div>
						<label class="wcvg-check"><input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[logging]" value="1" <?php checked( $this->settings['logging'], 1 ); ?>><span><strong>ثبت گزارش رویدادها</strong><small>نتیجه بررسی‌ها را بدون ذخیره IP خام و با شناسه هش‌شده نگهداری می‌کند.</small></span></label>
				
					</section>
					<?php submit_button( 'ذخیره همه تنظیمات', 'primary wcvg-save-button' ); ?>
				</main><aside>
					<div class="wcvg-card wcvg-side-card"><h2>وضعیت سیستم</h2><p><b>نسخه افزونه:</b> <?php echo esc_html( WCVG_VERSION ); ?></p><p><b>مکان‌یابی محلی:</b> <?php echo class_exists( 'WC_Geolocation' ) ? 'قابل استفاده از طریق ووکامرس' : 'در دسترس نیست'; ?></p><p><b>کلید VPN:</b> <?php echo $this->settings['vpn_api_key'] ? 'تنظیم شده' : 'تنظیم نشده'; ?></p><p class="description">برای تشخیص کشور بدون درخواست بیرونی، دیتابیس MaxMind ووکامرس باید در تنظیمات ووکامرس نصب و فعال باشد.</p>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wcvg_test_geo' ), 'wcvg_test_geo' ) ); ?>">آزمایش تشخیص کشور من</a>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wcvg_test_vpn' ), 'wcvg_test_vpn' ) ); ?>">آزمایش سرویس VPN</a>
					</div>
					<div class="wcvg-card wcvg-side-card"><h2>نکات مهم</h2><ul><li>ابتدا افزونه را در حالت آزمایشی فعال کنید.</li><li>حالت خطا را روی اجازه ادامه پرداخت بگذارید.</li><li>محدودیت کشور به دیتابیس محلی GeoLite2 ووکامرس وابسته است.</li><li>تشخیص VPN صددرصدی نیست و فقط با سرویس مستقل فعال می‌شود.</li><li>درخواست‌های بازگشت و تأیید درگاه عمداً از بررسی مستثنا هستند.</li><li>پیش از انتشار، پرداخت واقعی آزمایشی با چند درگاه انجام دهید.</li></ul></div>
					<?php if ( is_array( $logs ) && $logs ) : ?><div class="wcvg-card wcvg-side-card"><h2>آخرین رویدادها</h2><ul class="wcvg-log-list"><?php foreach ( array_slice( array_reverse( $logs ), 0, 10 ) as $log ) : ?><li><b><?php echo esc_html( $log['result'] ); ?></b><small><?php echo esc_html( $log['time'] ); ?> · <?php echo esc_html( $log['ip_hash'] ); ?></small></li><?php endforeach; ?></ul></div><?php endif; ?>
				</aside></div>
			</form>
		</div>
		<?php
	}
}
