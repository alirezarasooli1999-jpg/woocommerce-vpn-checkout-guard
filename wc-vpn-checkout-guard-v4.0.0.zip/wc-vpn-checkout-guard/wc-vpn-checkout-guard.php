<?php
/**
 * Plugin Name: محافظ پرداخت ووکامرس | تشخیص کشور و VPN
 * Description: محدودسازی پرداخت بر اساس کشور و بررسی اختیاری VPN و Proxy، همراه با هشدار فارسی و قابل شخصی‌سازی.
 * Version: 4.0.0
 * Requires at least: 6.7
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: توسعه اختصاصی
 * Text Domain: wc-vpn-checkout-guard
 * Domain Path: /languages
 * WC requires at least: 9.9
 * WC tested up to: 11.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WCVG_VERSION', '4.0.0' );
define( 'WCVG_FILE', __FILE__ );
define( 'WCVG_PATH', plugin_dir_path( __FILE__ ) );
define( 'WCVG_URL', plugin_dir_url( __FILE__ ) );

require_once WCVG_PATH . 'includes/class-wcvg-plugin.php';

add_action( 'plugins_loaded', function () {
	if ( class_exists( 'WooCommerce' ) ) {
		WCVG_Plugin::instance();
	} else {
		add_action( 'admin_notices', function () {
			if ( current_user_can( 'activate_plugins' ) ) {
				echo '<div class="notice notice-warning"><p>افزونه «محافظ پرداخت ووکامرس» برای فعالیت به افزونه ووکامرس نیاز دارد.</p></div>';
			}
		} );
	}
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=wcvg-settings' ) ) . '">تنظیمات</a>';
	array_unshift( $links, $settings_link );
	return $links;
} );
